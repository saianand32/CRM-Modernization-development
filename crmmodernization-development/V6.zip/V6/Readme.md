# CRM Modernization - V6

## Application Status

New version includes cloud-based authentication service

## Application Architecture

AWS Cognito has been defined as the best option for authentication service instead of maintaining their own service

## Development Process

Previous attempt to enable homemade SpringBoot service has been removed and replaced by AWS Cognito service
